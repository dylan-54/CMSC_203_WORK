
/**
 * Author: Dylan De Leon
 * CMSC 203 
 */
public enum Format 
{
	
  IMAX, THREE_D, NONE
  
}
